<?php
//==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>
//
// Address Book Script v1.18 [G110]
// Copyright (c) phpkobo.com ( http://www.phpkobo.com/ )
// Email : admin@phpkobo.com
// ID : AB201-118 [G110]
// URL : http://www.phpkobo.com/address_book.php
//
// This software is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2 of the
// License.
//
//==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<


require( "CUtil.inc.php" );
require( "CStr.inc.php" );
require( "CMBStr.inc.php" );
require( "CPath.inc.php" );
require( "CValidator.inc.php" );
require( "CEmail.inc.php" );
require( "CDoubleSubmitCheck.inc.php" );
require( "CToHtml.inc.php" );
require( "CConsole.inc.php" );
require( "CGenLog.inc.php" );

?>