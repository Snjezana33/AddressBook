<?php
//==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>
//
// Address Book Script v1.18 [G110]
// Copyright (c) phpkobo.com ( http://www.phpkobo.com/ )
// Email : admin@phpkobo.com
// ID : AB201-118 [G110]
// URL : http://www.phpkobo.com/address_book.php
//
// This software is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2 of the
// License.
//
//==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<

$spec = array(

'customers_id'=>array(
XA_CLASS=>'CVPrimaryKey',
XA_CAPTION=>RSTR_CUSTOMERS_ID,
XA_SIZE=>9,
XA_REQUIRED=>false,
XA_MAX_CHAR=>9,
XA_SB_SIZE=>9,
XA_LIST=>'(sp)(sr)(key)'
),

'active'=>array(
XA_CLASS=>'cls_active',
XA_CAPTION=>RSTR_ACTIVE,
XA_INIT_VALUE=>array( 'reg'=>'Y', 'search'=>'Y' ),
XA_REQUIRED=>true,
XA_SELECT_ON_TOP=>STR_SELECT_CAPTION,
XA_SEARCH_OP=>'s=',
XA_LIST=>'(sp)(sr)(fd)'
),

'active_Y' => array(
XA_CLASS=>'CVRadio',
XA_NAME_RS=>nothing,
XA_REQUIRED=>false,
XA_LINKED_TO=>'active',
XA_RADIO_VALUE=>'Y',
XA_LIST=>'(fd)'
),

'active_N' => array(
XA_CLASS=>'CVRadio',
XA_NAME_RS=>nothing,
XA_REQUIRED=>false,
XA_LINKED_TO=>'active',
XA_RADIO_VALUE=>'N',
XA_LIST=>'(fd)'
),

'first_name'=>array(
XA_CLASS=>'CVText',
XA_CAPTION=>RSTR_FIRST_NAME,
XA_REQUIRED=>false,
XA_SIZE=>24,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>36,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'last_name'=>array(
XA_CLASS=>'CVText',
XA_CAPTION=>RSTR_LAST_NAME,
XA_REQUIRED=>false,
XA_SIZE=>24,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>36,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'home_phone'=>array(
XA_CLASS=>'CVText',
XA_CAPTION=>RSTR_HOME_PHONE,
XA_REQUIRED=>false,
XA_SIZE=>24,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>36,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'home_phone2'=>array(
XA_CLASS=>'CVText',
XA_CAPTION=>RSTR_HOME_PHONE2,
XA_REQUIRED=>false,
XA_SIZE=>24,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>36,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'mobile_phone'=>array(
XA_CLASS=>'CVText',
XA_CAPTION=>RSTR_MOBILE_PHONE,
XA_REQUIRED=>false,
XA_SIZE=>24,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>36,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'other_phone'=>array(
XA_CLASS=>'CVText',
XA_CAPTION=>RSTR_OTHER_PHONE,
XA_REQUIRED=>false,
XA_SIZE=>24,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>36,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'primary_phone'=>array(
XA_CLASS=>'CVText',
XA_CAPTION=>RSTR_PRIMARY_PHONE,
XA_REQUIRED=>false,
XA_SIZE=>24,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>36,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'business_phone'=>array(
XA_CLASS=>'CVText',
XA_CAPTION=>RSTR_BUSINESS_PHONE,
XA_REQUIRED=>false,
XA_SIZE=>24,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>36,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'anniversary'=>array(
XA_CLASS=>'CVText',
XA_CAPTION=>RSTR_ANNIVERSARY,
XA_REQUIRED=>false,
XA_SIZE=>12,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>12,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'birthday'=>array(
XA_CLASS=>'CVText',
XA_CAPTION=>RSTR_BIRTHDAY,
XA_REQUIRED=>false,
XA_SIZE=>12,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>12,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'categories'=>array(
XA_CLASS=>'CVSelection',
XA_CAPTION=>RSTR_CATEGORIES,
XA_REQUIRED=>false,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>12,
XA_SEL_TEXT=>SEL_CATEGORIES,
XA_SELECT_ON_TOP=>STR_SELECT_CAPTION,
XA_SEARCH_OP=>'s=',
XA_LIST=>'(sp)(sr)(fd)',
),

'email'=>array(
XA_CLASS=>'CVText',
XA_CAPTION=>RSTR_EMAIL,
XA_REQUIRED=>false,
XA_SIZE=>24,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>100,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'email_display_name'=>array(
XA_CLASS=>'CVText',
XA_CAPTION=>RSTR_EMAIL_DISPLAY_NAME,
XA_REQUIRED=>false,
XA_SIZE=>20,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>36,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'home_street'=>array(
XA_CLASS=>'CVText',
XA_CAPTION=>RSTR_HOME_STREET,
XA_REQUIRED=>false,
XA_SIZE=>40,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>100,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'home_street2'=>array(
XA_CLASS=>'CVText',
XA_CAPTION=>RSTR_HOME_STREET2,
XA_REQUIRED=>false,
XA_SIZE=>40,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>100,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'home_city'=>array(
XA_CLASS=>'CVText',
XA_CAPTION=>RSTR_HOME_CITY,
XA_REQUIRED=>false,
XA_SIZE=>24,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>64,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'home_state'=>array(
XA_CLASS=>'CVText',
XA_CAPTION=>RSTR_HOME_STATE,
XA_REQUIRED=>false,
XA_SIZE=>24,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>64,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'home_zip'=>array(
XA_CLASS=>'CVText',
XA_CAPTION=>RSTR_HOME_ZIP,
XA_REQUIRED=>false,
XA_SIZE=>15,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>20,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'note'=>array(
XA_CLASS=>'CVTextArea',
XA_CAPTION=>RSTR_NOTE,
XA_REQUIRED=>false,
XA_COLS=>48,
XA_ROWS=>18,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>3000,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'year'=>array(
XA_CLASS=>'CVText',
XA_CAPTION=>RSTR_YEAR,
XA_REQUIRED=>false,
XA_SIZE=>12,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>12,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'date_added'=>array(
XA_CLASS=>'CVText',
XA_CAPTION=>RSTR_DATE_ADDED,
XA_REQUIRED=>false,
XA_SIZE=>12,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>12,
XA_SEARCH_OP=>'s%',
XA_LIST=>'(sp)(sr)(fd)',
),

'news_letter'=>array(
XA_CLASS=>'CVCheckBox',
XA_CAPTION=>RSTR_NEWS_LETTER,
XA_REQUIRED=>false,
XA_SIZE=>1,
XA_MIN_CHAR=>0,
XA_MAX_CHAR=>1,
XA_SEARCH_OP=>'s=',
XA_LIST=>'(sp)(sr)(fd)',
),

'rlog_create_date_time'=>array(
XA_CLASS=>'cls_rlog_date_time',
XA_CAPTION=>RSTR_CREATE_DATE_TIME,
XA_FORMAT=>'Y-m-d H:i:s',
XA_LIST=>'(rlog)(reg_save)'
),

'rlog_create_user_type'=>array(
XA_CLASS=>'cls_rlog_user_type',
XA_CAPTION=>RSTR_CREATE_USER_TYPE,
XA_LIST=>'(rlog)(reg_save)'
),

'rlog_create_user_id'=>array(
XA_CLASS=>'cls_rlog_user_id',
XA_CAPTION=>RSTR_CREATE_USER_NAME,
XA_LIST=>'(rlog)(reg_save)'
),

'rlog_create_user_name'=>array(
XA_CLASS=>'cls_rlog_user_name',
XA_CAPTION=>RSTR_CREATE_USER_NAME,
XA_LIST=>'(rlog)(reg_save)'
),

'rlog_edit_date_time'=>array(
XA_CLASS=>'cls_rlog_date_time',
XA_CAPTION=>RSTR_EDIT_DATE_TIME,
XA_FORMAT=>'Y-m-d H:i:s',
XA_LIST=>'(rlog)(edit_save)'
),

'rlog_edit_user_type'=>array(
XA_CLASS=>'cls_rlog_user_type',
XA_CAPTION=>RSTR_EDIT_USER_TYPE,
XA_LIST=>'(rlog)(edit_save)'
),

'rlog_edit_user_id'=>array(
XA_CLASS=>'cls_rlog_user_id',
XA_CAPTION=>RSTR_EDIT_USER_NAME,
XA_LIST=>'(rlog)(edit_save)'
),

'rlog_edit_user_name'=>array(
XA_CLASS=>'cls_rlog_user_name',
XA_CAPTION=>RSTR_EDIT_USER_NAME,
XA_LIST=>'(rlog)(edit_save)'
),

);

?>