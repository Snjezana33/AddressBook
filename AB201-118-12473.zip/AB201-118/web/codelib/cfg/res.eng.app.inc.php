<?php
//==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>
//
// Address Book Script v1.18 [G110]
// Copyright (c) phpkobo.com ( http://www.phpkobo.com/ )
// Email : admin@phpkobo.com
// ID : AB201-118 [G110]
// URL : http://www.phpkobo.com/address_book.php
//
// This software is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2 of the
// License.
//
//==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<

//-- Script Title
define( 'RSTR_APP_TITLE', "Customer List" );

//-- About
define( 'RSTR_ABOUT', 'About' );

//-- Staff
define( 'RSTR_STAFF', 'Staff' );
define( 'RSTR_STAFF_ID', 'ID' );
define( 'RSTR_ACTIVE', 'Active' );
define( 'RSTR_STAFF_TYPE', 'Staff Type' );
define( 'RSTR_PASSWORD_CONF', 'Password (Confirmation)' );
define( 'RSTR_LEAVE_PASSWORD_BLANK',
	'(Leave it blank to keep the current password.)' );
define( 'RSTR_EMAIL', 'Email' );
define( 'RSTR_NAME', 'Name' );

//-- Customers 
define( 'RSTR_CUSTOMERS', "Customers" );
define( 'RSTR_CUSTOMERS_ID', 'ID' );
define( 'RSTR_FIRST_NAME', "First Name" );
define( 'RSTR_LAST_NAME', "Last Name" );
define( 'RSTR_HOME_PHONE', "Home Phone" );
define( 'RSTR_HOME_PHONE2', "Home Phone2" );
define( 'RSTR_MOBILE_PHONE', "Mobile Phone" );
define( 'RSTR_OTHER_PHONE', "Other Phone" );
define( 'RSTR_PRIMARY_PHONE', "Primary Phone" );
define( 'RSTR_BUSINESS_PHONE', "Business Phone" );
define( 'RSTR_ANNIVERSARY', "Anniversary" );
define( 'RSTR_BIRTHDAY', "Birthday" );
define( 'RSTR_CATEGORIES', "Categories" );
//define( 'RSTR_EMAIL', "Email" );
define( 'RSTR_EMAIL_DISPLAY_NAME', "Email Display Name" );
define( 'RSTR_HOME_STREET', "Home Street" );
define( 'RSTR_HOME_STREET2', "Home Street2" );
define( 'RSTR_HOME_CITY', "Home City" );
define( 'RSTR_HOME_STATE', "Home State" );
define( 'RSTR_HOME_ZIP', "Home Zip" );
define( 'RSTR_NOTE', "Note" );
define( 'RSTR_YEAR', "Year" );
define( 'RSTR_DATE_ADDED', "Date Added" );
define( 'RSTR_NEWS_LETTER', "News Letter" );
define( 'RSTR2_NEWS_LETTER', "" );

//----------------------------------------------------------------
// END OF FILE
//----------------------------------------------------------------

?>
