<!-- [BEGIN] Page Footer -->
<div style='margin:0px;padding:0px;height:1px;
	border:1px solid #ffffff;background-color:#8080ff;'>
</div>
<div style='text-align:center;padding:10px;'>
	<a style='text-decoration:none;color:#c0c0c0;font-weight:bold;font-style:italic;'
		href='http://www.phpkobo.com/address_book.php' target='_blank'>
www.phpkobo.com	</a>
</div>
<!-- [END] Page Footer -->
