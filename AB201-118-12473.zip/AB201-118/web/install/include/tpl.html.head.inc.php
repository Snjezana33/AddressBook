<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php $css = _LANG_FILE_( "css/style.##LANG_CODE##.css" ); ?>
<link href="<?php echo $css; ?>" rel="stylesheet" type="text/css"/>
<title>Customer List&nbsp;<?php echo RSTR_INSTALL_INSTALLATION; ?></title>
