<!-- [BEGIN] jQuery -->
<script type="text/javascript" src="js/jquery/jquery.js"></script>
<!-- [END] jQuery -->

