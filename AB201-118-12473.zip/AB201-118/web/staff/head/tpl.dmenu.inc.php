<!-- [BEGIN] dmenu -->
<link href="js/dmenu/css/dmenu.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="js/dmenu/init.js"></script>
<!-- [END] dmenu -->
