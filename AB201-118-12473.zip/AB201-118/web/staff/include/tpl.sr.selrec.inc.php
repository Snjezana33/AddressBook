			<td style='text-align:center;'><input
				type='checkbox'
				class='selrec_checkbox'
				name='_selrec_[]'
				value='<?php echo $def_id; ?>'
				title='<?php echo RSTR_SELREC_CHECKBOX; ?>'
			/></td>
