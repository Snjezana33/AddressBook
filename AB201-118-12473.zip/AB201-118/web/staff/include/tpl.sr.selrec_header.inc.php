<input type='checkbox' id='selrec_header' title='<?php echo RSTR_SELREC_HEADER; ?>'/>
