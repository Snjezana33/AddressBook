			<?php
				$def_id = $hm->Zb("rs:def:" . $hm->GetDefID() );
				$param = "key:def:" . $hm->GetDefID() . "=" . $def_id;
			?>