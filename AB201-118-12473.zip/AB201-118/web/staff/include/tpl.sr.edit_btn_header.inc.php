<img src='<?php echo $hm->GetImagePath(); ?>btn_icon_edit.gif' title='<?php echo RSTR_EDIT; ?>'/>
