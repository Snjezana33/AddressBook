<?php include(INC_HTML_TAG); ?>
<?php $hm->Title( __FILE__, RSTR_APP_TITLE, RSTR_CUSTOMERS, RSTR_SEARCH ); ?>

<head><?php include(INC_HTML_HEADER); ?></head>

<body>

<!-- [BEGIN] Container -->
<div id="container">

<?php include(INC_BODY_HEADER); ?>

<!-- [BEGIN] Main Form -->
<div id="main_div">

<?php include(INC_FORM_BEGIN); ?>

<?php include(INC_BODY_INFO); ?>

	<!-- [BEGIN] Search Criteria -->
	<?php echo $hm->SectBegin( RSTR_SEARCH_CRITERIA ); ?>

	<div style='overflow:auto;'>
	<table width='99%'>

	<tr>
		<td align="right"><?php echo RSTR_CUSTOMERS_ID; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:customers_id' ); ?></td>
		<td align="right"><?php echo RSTR_ACTIVE; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:active' ); ?></td>
		<td align="right"><?php echo RSTR_FIRST_NAME; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:first_name' ); ?></td>
	</tr>

	<tr>
		<td align="right"><?php echo RSTR_LAST_NAME; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:last_name' ); ?></td>
		<td align="right"><?php echo RSTR_HOME_PHONE; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:home_phone' ); ?></td>
		<td align="right"><?php echo RSTR_HOME_PHONE2; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:home_phone2' ); ?></td>
	</tr>

	<tr>
		<td align="right"><?php echo RSTR_MOBILE_PHONE; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:mobile_phone' ); ?></td>
		<td align="right"><?php echo RSTR_OTHER_PHONE; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:other_phone' ); ?></td>
		<td align="right"><?php echo RSTR_PRIMARY_PHONE; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:primary_phone' ); ?></td>
	</tr>

	<tr>
		<td align="right"><?php echo RSTR_BUSINESS_PHONE; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:business_phone' ); ?></td>
		<td align="right"><?php echo RSTR_ANNIVERSARY; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:anniversary' ); ?></td>
		<td align="right"><?php echo RSTR_BIRTHDAY; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:birthday' ); ?></td>
	</tr>

	<tr>
		<td align="right"><?php echo RSTR_CATEGORIES; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:categories' ); ?></td>
		<td align="right"><?php echo RSTR_EMAIL; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:email' ); ?></td>
		<td align="right"><?php echo RSTR_EMAIL_DISPLAY_NAME; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:email_display_name' ); ?></td>
	</tr>

	<tr>
		<td align="right"><?php echo RSTR_HOME_STREET; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:home_street' ); ?></td>
		<td align="right"><?php echo RSTR_HOME_STREET2; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:home_street2' ); ?></td>
		<td align="right"><?php echo RSTR_HOME_CITY; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:home_city' ); ?></td>
	</tr>

	<tr>
		<td align="right"><?php echo RSTR_HOME_STATE; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:home_state' ); ?></td>
		<td align="right"><?php echo RSTR_HOME_ZIP; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:home_zip' ); ?></td>
		<td align="right"><?php echo RSTR_NOTE; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:note' ); ?></td>
	</tr>

	<tr>
		<td align="right"><?php echo RSTR_YEAR; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:year' ); ?></td>
		<td align="right"><?php echo RSTR_DATE_ADDED; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:date_added' ); ?></td>
		<td align="right"><?php echo RSTR_NEWS_LETTER; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:news_letter' ); ?></td>
	</tr>

	<tr>
		<td align="right">&nbsp;</td>
		<td align="left">&nbsp;</td>
		<td align="right">&nbsp;</td>
		<td align="left">&nbsp;</td>
		<td align="right">&nbsp;</td>
		<td align="right"><?php echo $hm->Button(
			array( '<>'=>'</>',
			'name'=>"_sc=_this/search_pb&",
			'src'=>'search',
			'value'=>RSTR_SEARCH,
		) ); ?></td>
	</tr>

	</table>
	</div>

	<?php echo $hm->SectEnd(); ?>
	<!-- [END] Search Criteria-->

	<!-- [BEGIN] Search Result -->
	<?php if ( $hm->Zb("def:display?") ) { ?>

	<?php echo $hm->SectBegin( RSTR_SEARCH_RESULT ); ?>

	<?php include(INC_SR_TOP_BAR); ?>

	<div style='overflow:auto;'>
	<table class='data_table'>

		<tr class='data_table_caption'>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:customers_id'); ?>
				<?php echo RSTR_CUSTOMERS_ID; ?></th>
			<th><?php include(INC_SR_SELREC_HEADER); ?></th>
			<th><?php include(INC_SR_EDIT_BTN_HEADER); ?></th>
			<th><?php echo RSTR_ACTIVE; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:first_name'); ?> <?php echo RSTR_FIRST_NAME; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:last_name'); ?> <?php echo RSTR_LAST_NAME; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:home_phone'); ?> <?php echo RSTR_HOME_PHONE; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:home_phone2'); ?> <?php echo RSTR_HOME_PHONE2; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:mobile_phone'); ?> <?php echo RSTR_MOBILE_PHONE; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:other_phone'); ?> <?php echo RSTR_OTHER_PHONE; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:primary_phone'); ?> <?php echo RSTR_PRIMARY_PHONE; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:business_phone'); ?> <?php echo RSTR_BUSINESS_PHONE; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:anniversary'); ?> <?php echo RSTR_ANNIVERSARY; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:birthday'); ?> <?php echo RSTR_BIRTHDAY; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:categories'); ?> <?php echo RSTR_CATEGORIES; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:email'); ?> <?php echo RSTR_EMAIL; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:email_display_name'); ?> <?php echo RSTR_EMAIL_DISPLAY_NAME; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:home_street'); ?> <?php echo RSTR_HOME_STREET; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:home_street2'); ?> <?php echo RSTR_HOME_STREET2; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:home_city'); ?> <?php echo RSTR_HOME_CITY; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:home_state'); ?> <?php echo RSTR_HOME_STATE; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:home_zip'); ?> <?php echo RSTR_HOME_ZIP; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:note'); ?> <?php echo RSTR_NOTE; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:year'); ?> <?php echo RSTR_YEAR; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:date_added'); ?> <?php echo RSTR_DATE_ADDED; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:news_letter'); ?> <?php echo RSTR_NEWS_LETTER; ?></th>
		</tr>

		<?php while( $hm->zb('@rs:def:begin_table') ) { ?>
		<tr>
			<td style='text-align:right;'><?php echo $hm->Zb('rs:def:customers_id'); ?></td>
			<?php include(INC_SR_ID_PARAM); ?>
			<?php include(INC_SR_SELREC); ?>
			<?php include(INC_SR_EDIT_BTN); ?>
			<td style='text-align:center;'><?php echo $hm->Zb('rs:def:active'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:first_name'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:last_name'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:home_phone'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:home_phone2'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:mobile_phone'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:other_phone'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:primary_phone'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:business_phone'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:anniversary'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:birthday'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:categories'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:email'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:email_display_name'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:home_street'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:home_street2'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:home_city'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:home_state'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:home_zip'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:note'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:year'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:date_added'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:news_letter'); ?></td>
		</tr>
		<?php } ?>

	</table>
	</div>

	<?php include(INC_SR_BOTTOM_BAR); ?>

	<?php echo $hm->SectEnd(); ?>

	<?php } ?>
	<!-- [END] Search Result -->

	<?php echo $hm->SectEndMarker(); ?>

<?php include(INC_FORM_END); ?>

</div>
<!-- [END] Main Form -->

<?php include(INC_BODY_FOOTER); ?>

</div>
<!-- [END] Container -->

</body>
</html>

<?php include(INC_HTML_END); ?>