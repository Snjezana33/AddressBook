
//-- Deletion
var RSTR_SELECT_AT_LEAST_ONE = 'Please select at least one checkbox to delete records.';
var RSTR_DELETE_CONFIRM = 'You are about to delete ##cnt## record##s##.\r\nDo you want to proceed?';

